Milestone 4 and 5, CST 117 can be found here:
https://github.com/Finsternavy/CST-117/tree/main/GPU_Inventory

YouTube link:https://www.youtube.com/watch?v=BAqTJfd7_cQ

Milestone 4 and Milestrone 5 differences:

Milestone 4 covers the original requirements of the program.  That includs add, delete, updated, search, and setting the inventory 
methods.  

Milestone 5 adds the hide control panel feature as well as the lock screen. 

