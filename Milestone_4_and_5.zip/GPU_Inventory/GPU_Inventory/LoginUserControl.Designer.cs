﻿
namespace GPU_Inventory
{
    partial class LoginUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginUserControl));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.poundButton = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.asteriskButton = new System.Windows.Forms.Button();
            this.digit1Label = new System.Windows.Forms.Label();
            this.digit2Label = new System.Windows.Forms.Label();
            this.digit3Label = new System.Windows.Forms.Label();
            this.digit4Label = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(372, 291);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 87);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.Transparent;
            this.button2.Location = new System.Drawing.Point(488, 291);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 87);
            this.button2.TabIndex = 0;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(601, 291);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 87);
            this.button3.TabIndex = 0;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.Transparent;
            this.button4.Location = new System.Drawing.Point(372, 401);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(88, 87);
            this.button4.TabIndex = 0;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.Transparent;
            this.button5.Location = new System.Drawing.Point(488, 401);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(88, 87);
            this.button5.TabIndex = 0;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.Transparent;
            this.button6.Location = new System.Drawing.Point(601, 401);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(88, 87);
            this.button6.TabIndex = 0;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.Transparent;
            this.button7.Location = new System.Drawing.Point(372, 510);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(88, 87);
            this.button7.TabIndex = 0;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.Transparent;
            this.button8.Location = new System.Drawing.Point(488, 510);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(88, 87);
            this.button8.TabIndex = 0;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.Transparent;
            this.button9.Location = new System.Drawing.Point(601, 510);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(88, 87);
            this.button9.TabIndex = 0;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // poundButton
            // 
            this.poundButton.BackColor = System.Drawing.Color.Transparent;
            this.poundButton.FlatAppearance.BorderSize = 0;
            this.poundButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.poundButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.poundButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.poundButton.ForeColor = System.Drawing.Color.Transparent;
            this.poundButton.Location = new System.Drawing.Point(372, 618);
            this.poundButton.Name = "poundButton";
            this.poundButton.Size = new System.Drawing.Size(88, 87);
            this.poundButton.TabIndex = 0;
            this.poundButton.UseVisualStyleBackColor = false;
            this.poundButton.Click += new System.EventHandler(this.poundButton_Click_1);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.Color.Transparent;
            this.button0.FlatAppearance.BorderSize = 0;
            this.button0.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button0.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button0.ForeColor = System.Drawing.Color.Transparent;
            this.button0.Location = new System.Drawing.Point(488, 618);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(88, 87);
            this.button0.TabIndex = 0;
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // asteriskButton
            // 
            this.asteriskButton.BackColor = System.Drawing.Color.Transparent;
            this.asteriskButton.FlatAppearance.BorderSize = 0;
            this.asteriskButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.asteriskButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.asteriskButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.asteriskButton.ForeColor = System.Drawing.Color.Transparent;
            this.asteriskButton.Location = new System.Drawing.Point(601, 618);
            this.asteriskButton.Name = "asteriskButton";
            this.asteriskButton.Size = new System.Drawing.Size(88, 87);
            this.asteriskButton.TabIndex = 0;
            this.asteriskButton.UseVisualStyleBackColor = false;
            this.asteriskButton.Click += new System.EventHandler(this.asteriskButton_Click);
            // 
            // digit1Label
            // 
            this.digit1Label.AutoSize = true;
            this.digit1Label.BackColor = System.Drawing.Color.Transparent;
            this.digit1Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.digit1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digit1Label.Location = new System.Drawing.Point(397, 161);
            this.digit1Label.Name = "digit1Label";
            this.digit1Label.Size = new System.Drawing.Size(63, 69);
            this.digit1Label.TabIndex = 1;
            this.digit1Label.Text = "_";
            // 
            // digit2Label
            // 
            this.digit2Label.AutoSize = true;
            this.digit2Label.BackColor = System.Drawing.Color.Transparent;
            this.digit2Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.digit2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digit2Label.Location = new System.Drawing.Point(466, 161);
            this.digit2Label.Name = "digit2Label";
            this.digit2Label.Size = new System.Drawing.Size(63, 69);
            this.digit2Label.TabIndex = 1;
            this.digit2Label.Text = "_";
            // 
            // digit3Label
            // 
            this.digit3Label.AutoSize = true;
            this.digit3Label.BackColor = System.Drawing.Color.Transparent;
            this.digit3Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.digit3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digit3Label.Location = new System.Drawing.Point(535, 161);
            this.digit3Label.Name = "digit3Label";
            this.digit3Label.Size = new System.Drawing.Size(63, 69);
            this.digit3Label.TabIndex = 1;
            this.digit3Label.Text = "_";
            // 
            // digit4Label
            // 
            this.digit4Label.AutoSize = true;
            this.digit4Label.BackColor = System.Drawing.Color.Transparent;
            this.digit4Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.digit4Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digit4Label.Location = new System.Drawing.Point(604, 161);
            this.digit4Label.Name = "digit4Label";
            this.digit4Label.Size = new System.Drawing.Size(63, 69);
            this.digit4Label.TabIndex = 1;
            this.digit4Label.Text = "_";
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Transparent;
            this.exitButton.FlatAppearance.BorderSize = 0;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(1053, 3);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(37, 34);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "X";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // LoginUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.digit4Label);
            this.Controls.Add(this.digit3Label);
            this.Controls.Add(this.digit2Label);
            this.Controls.Add(this.digit1Label);
            this.Controls.Add(this.asteriskButton);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.poundButton);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Name = "LoginUserControl";
            this.Size = new System.Drawing.Size(1093, 853);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button poundButton;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button asteriskButton;
        private System.Windows.Forms.Label digit1Label;
        private System.Windows.Forms.Label digit2Label;
        private System.Windows.Forms.Label digit3Label;
        private System.Windows.Forms.Label digit4Label;
        private System.Windows.Forms.Button exitButton;
    }
}
