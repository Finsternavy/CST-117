Executable located in the following file path:

Exercise_4 > obj > Debug > Exercise_4.exe