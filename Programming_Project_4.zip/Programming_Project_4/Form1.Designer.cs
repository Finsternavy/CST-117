﻿
namespace Programming_Project_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.spaceTopLeft = new System.Windows.Forms.Label();
            this.spaceTopMid = new System.Windows.Forms.Label();
            this.spaceTopRight = new System.Windows.Forms.Label();
            this.spaceMidLeft = new System.Windows.Forms.Label();
            this.spaceMidMid = new System.Windows.Forms.Label();
            this.spaceMidRight = new System.Windows.Forms.Label();
            this.spaceBottomLeft = new System.Windows.Forms.Label();
            this.spaceBottomMid = new System.Windows.Forms.Label();
            this.spaceBottomRight = new System.Windows.Forms.Label();
            this.winnerTextBox = new System.Windows.Forms.TextBox();
            this.newGameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // spaceTopLeft
            // 
            this.spaceTopLeft.AutoSize = true;
            this.spaceTopLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceTopLeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceTopLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceTopLeft.Location = new System.Drawing.Point(45, 20);
            this.spaceTopLeft.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceTopLeft.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceTopLeft.Name = "spaceTopLeft";
            this.spaceTopLeft.Size = new System.Drawing.Size(103, 93);
            this.spaceTopLeft.TabIndex = 0;
            // 
            // spaceTopMid
            // 
            this.spaceTopMid.AutoSize = true;
            this.spaceTopMid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceTopMid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceTopMid.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceTopMid.Location = new System.Drawing.Point(163, 20);
            this.spaceTopMid.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceTopMid.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceTopMid.Name = "spaceTopMid";
            this.spaceTopMid.Size = new System.Drawing.Size(103, 93);
            this.spaceTopMid.TabIndex = 0;
            // 
            // spaceTopRight
            // 
            this.spaceTopRight.AutoSize = true;
            this.spaceTopRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceTopRight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceTopRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceTopRight.Location = new System.Drawing.Point(281, 20);
            this.spaceTopRight.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceTopRight.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceTopRight.Name = "spaceTopRight";
            this.spaceTopRight.Size = new System.Drawing.Size(103, 93);
            this.spaceTopRight.TabIndex = 0;
            // 
            // spaceMidLeft
            // 
            this.spaceMidLeft.AutoSize = true;
            this.spaceMidLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceMidLeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceMidLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceMidLeft.Location = new System.Drawing.Point(45, 123);
            this.spaceMidLeft.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceMidLeft.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceMidLeft.Name = "spaceMidLeft";
            this.spaceMidLeft.Size = new System.Drawing.Size(103, 93);
            this.spaceMidLeft.TabIndex = 0;
            // 
            // spaceMidMid
            // 
            this.spaceMidMid.AutoSize = true;
            this.spaceMidMid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceMidMid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceMidMid.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceMidMid.Location = new System.Drawing.Point(163, 123);
            this.spaceMidMid.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceMidMid.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceMidMid.Name = "spaceMidMid";
            this.spaceMidMid.Size = new System.Drawing.Size(103, 93);
            this.spaceMidMid.TabIndex = 0;
            // 
            // spaceMidRight
            // 
            this.spaceMidRight.AutoSize = true;
            this.spaceMidRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceMidRight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceMidRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceMidRight.Location = new System.Drawing.Point(281, 123);
            this.spaceMidRight.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceMidRight.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceMidRight.Name = "spaceMidRight";
            this.spaceMidRight.Size = new System.Drawing.Size(103, 93);
            this.spaceMidRight.TabIndex = 0;
            // 
            // spaceBottomLeft
            // 
            this.spaceBottomLeft.AutoSize = true;
            this.spaceBottomLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceBottomLeft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceBottomLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceBottomLeft.Location = new System.Drawing.Point(45, 225);
            this.spaceBottomLeft.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceBottomLeft.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceBottomLeft.Name = "spaceBottomLeft";
            this.spaceBottomLeft.Size = new System.Drawing.Size(103, 93);
            this.spaceBottomLeft.TabIndex = 0;
            // 
            // spaceBottomMid
            // 
            this.spaceBottomMid.AutoSize = true;
            this.spaceBottomMid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceBottomMid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceBottomMid.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceBottomMid.Location = new System.Drawing.Point(163, 225);
            this.spaceBottomMid.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceBottomMid.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceBottomMid.Name = "spaceBottomMid";
            this.spaceBottomMid.Size = new System.Drawing.Size(103, 93);
            this.spaceBottomMid.TabIndex = 0;
            // 
            // spaceBottomRight
            // 
            this.spaceBottomRight.AutoSize = true;
            this.spaceBottomRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spaceBottomRight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spaceBottomRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spaceBottomRight.Location = new System.Drawing.Point(281, 225);
            this.spaceBottomRight.MaximumSize = new System.Drawing.Size(103, 93);
            this.spaceBottomRight.MinimumSize = new System.Drawing.Size(103, 93);
            this.spaceBottomRight.Name = "spaceBottomRight";
            this.spaceBottomRight.Size = new System.Drawing.Size(103, 93);
            this.spaceBottomRight.TabIndex = 0;
            // 
            // winnerTextBox
            // 
            this.winnerTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.winnerTextBox.Enabled = false;
            this.winnerTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winnerTextBox.ForeColor = System.Drawing.Color.Gray;
            this.winnerTextBox.Location = new System.Drawing.Point(45, 336);
            this.winnerTextBox.Multiline = true;
            this.winnerTextBox.Name = "winnerTextBox";
            this.winnerTextBox.ReadOnly = true;
            this.winnerTextBox.Size = new System.Drawing.Size(339, 47);
            this.winnerTextBox.TabIndex = 1;
            this.winnerTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // newGameButton
            // 
            this.newGameButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newGameButton.Location = new System.Drawing.Point(73, 399);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(132, 39);
            this.newGameButton.TabIndex = 2;
            this.newGameButton.Text = "New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(211, 399);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(132, 39);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(440, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.newGameButton);
            this.Controls.Add(this.winnerTextBox);
            this.Controls.Add(this.spaceBottomRight);
            this.Controls.Add(this.spaceBottomMid);
            this.Controls.Add(this.spaceBottomLeft);
            this.Controls.Add(this.spaceMidRight);
            this.Controls.Add(this.spaceMidMid);
            this.Controls.Add(this.spaceMidLeft);
            this.Controls.Add(this.spaceTopRight);
            this.Controls.Add(this.spaceTopMid);
            this.Controls.Add(this.spaceTopLeft);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tic-Tac_Toe";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label spaceTopLeft;
        private System.Windows.Forms.Label spaceTopMid;
        private System.Windows.Forms.Label spaceTopRight;
        private System.Windows.Forms.Label spaceMidLeft;
        private System.Windows.Forms.Label spaceMidMid;
        private System.Windows.Forms.Label spaceMidRight;
        private System.Windows.Forms.Label spaceBottomLeft;
        private System.Windows.Forms.Label spaceBottomMid;
        private System.Windows.Forms.Label spaceBottomRight;
        private System.Windows.Forms.TextBox winnerTextBox;
        private System.Windows.Forms.Button newGameButton;
        private System.Windows.Forms.Button exitButton;
    }
}

