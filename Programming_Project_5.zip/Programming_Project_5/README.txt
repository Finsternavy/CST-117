Christopher Finster
Programming Project 5, random number generator
CST-117
17 Apr 2021

Calculates a lucky number based on user inputs and displays the result in another form. 
