File named "testTextFile.txt" used for testing all aspects when designed. 

strings named to indicated an intended result.  For example:  "ThisWordIsReallyLong" should display as the longest word.