﻿
namespace W1_Exercise_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inchesInputLable = new System.Windows.Forms.Label();
            this.inchesTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.millimetersLabel = new System.Windows.Forms.Label();
            this.millimetersTextBox = new System.Windows.Forms.TextBox();
            this.convertButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // inchesInputLable
            // 
            this.inchesInputLable.AutoSize = true;
            this.inchesInputLable.Location = new System.Drawing.Point(135, 97);
            this.inchesInputLable.Name = "inchesInputLable";
            this.inchesInputLable.Size = new System.Drawing.Size(39, 13);
            this.inchesInputLable.TabIndex = 0;
            this.inchesInputLable.Text = "Inches";
            this.inchesInputLable.Click += new System.EventHandler(this.label1_Click);
            // 
            // inchesTextBox
            // 
            this.inchesTextBox.Location = new System.Drawing.Point(211, 94);
            this.inchesTextBox.Name = "inchesTextBox";
            this.inchesTextBox.Size = new System.Drawing.Size(100, 20);
            this.inchesTextBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(121, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(248, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Convert inches to millimeters or millimeters to inches";
            // 
            // millimetersLabel
            // 
            this.millimetersLabel.AutoSize = true;
            this.millimetersLabel.Location = new System.Drawing.Point(135, 141);
            this.millimetersLabel.Name = "millimetersLabel";
            this.millimetersLabel.Size = new System.Drawing.Size(55, 13);
            this.millimetersLabel.TabIndex = 0;
            this.millimetersLabel.Text = "Millimeters";
            this.millimetersLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // millimetersTextBox
            // 
            this.millimetersTextBox.Location = new System.Drawing.Point(211, 138);
            this.millimetersTextBox.Name = "millimetersTextBox";
            this.millimetersTextBox.Size = new System.Drawing.Size(100, 20);
            this.millimetersTextBox.TabIndex = 1;
            // 
            // convertButton
            // 
            this.convertButton.Location = new System.Drawing.Point(211, 186);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(100, 23);
            this.convertButton.TabIndex = 2;
            this.convertButton.Text = "CONVERT";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click_1);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(211, 215);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(100, 23);
            this.clearButton.TabIndex = 2;
            this.clearButton.Text = "CLEAR";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 307);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.millimetersTextBox);
            this.Controls.Add(this.inchesTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.millimetersLabel);
            this.Controls.Add(this.inchesInputLable);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label inchesInputLable;
        private System.Windows.Forms.TextBox inchesTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label millimetersLabel;
        private System.Windows.Forms.TextBox millimetersTextBox;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Button clearButton;
    }
}

