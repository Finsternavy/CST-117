Milestone 3, CST 117 can be found here:
https://github.com/Finsternavy/CST-117/tree/main/GPU_Inventory

All files were pushed to my GitHub as I work on multiple computers and need to be able to push/pull to complete my work. 