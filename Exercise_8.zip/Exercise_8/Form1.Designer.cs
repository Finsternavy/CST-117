﻿
namespace Exercise_8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fatGramsLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.fatGramsTextBox = new System.Windows.Forms.TextBox();
            this.carbsGrams = new System.Windows.Forms.Label();
            this.carbsGramsTextBox = new System.Windows.Forms.TextBox();
            this.caloriesFromFatLabel = new System.Windows.Forms.Label();
            this.caloriesFromCarbsLabel = new System.Windows.Forms.Label();
            this.caloriesFromFatResultsLabel = new System.Windows.Forms.Label();
            this.caloriesFromCarbsResultsLabel = new System.Windows.Forms.Label();
            this.totalCaloriesLabel = new System.Windows.Forms.Label();
            this.totaCaloriesResultsLabel = new System.Windows.Forms.Label();
            this.convertButton = new System.Windows.Forms.Button();
            this.inputAdviseLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // fatGramsLabel
            // 
            this.fatGramsLabel.AutoSize = true;
            this.fatGramsLabel.Location = new System.Drawing.Point(182, 125);
            this.fatGramsLabel.Name = "fatGramsLabel";
            this.fatGramsLabel.Size = new System.Drawing.Size(55, 13);
            this.fatGramsLabel.TabIndex = 0;
            this.fatGramsLabel.Text = "Fat Grams";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(317, 52);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(92, 13);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Calorie Evaluation";
            // 
            // fatGramsTextBox
            // 
            this.fatGramsTextBox.Location = new System.Drawing.Point(243, 117);
            this.fatGramsTextBox.Name = "fatGramsTextBox";
            this.fatGramsTextBox.Size = new System.Drawing.Size(100, 20);
            this.fatGramsTextBox.TabIndex = 1;
            // 
            // carbsGrams
            // 
            this.carbsGrams.AutoSize = true;
            this.carbsGrams.Location = new System.Drawing.Point(170, 181);
            this.carbsGrams.Name = "carbsGrams";
            this.carbsGrams.Size = new System.Drawing.Size(67, 13);
            this.carbsGrams.TabIndex = 0;
            this.carbsGrams.Text = "Carbs Grams";
            // 
            // carbsGramsTextBox
            // 
            this.carbsGramsTextBox.Location = new System.Drawing.Point(243, 174);
            this.carbsGramsTextBox.Name = "carbsGramsTextBox";
            this.carbsGramsTextBox.Size = new System.Drawing.Size(100, 20);
            this.carbsGramsTextBox.TabIndex = 1;
            // 
            // caloriesFromFatLabel
            // 
            this.caloriesFromFatLabel.AutoSize = true;
            this.caloriesFromFatLabel.Location = new System.Drawing.Point(358, 125);
            this.caloriesFromFatLabel.Name = "caloriesFromFatLabel";
            this.caloriesFromFatLabel.Size = new System.Drawing.Size(85, 13);
            this.caloriesFromFatLabel.TabIndex = 0;
            this.caloriesFromFatLabel.Text = "Calories from fat:";
            // 
            // caloriesFromCarbsLabel
            // 
            this.caloriesFromCarbsLabel.AutoSize = true;
            this.caloriesFromCarbsLabel.Location = new System.Drawing.Point(358, 181);
            this.caloriesFromCarbsLabel.Name = "caloriesFromCarbsLabel";
            this.caloriesFromCarbsLabel.Size = new System.Drawing.Size(99, 13);
            this.caloriesFromCarbsLabel.TabIndex = 0;
            this.caloriesFromCarbsLabel.Text = "Calories from carbs:";
            // 
            // caloriesFromFatResultsLabel
            // 
            this.caloriesFromFatResultsLabel.AutoSize = true;
            this.caloriesFromFatResultsLabel.Location = new System.Drawing.Point(463, 124);
            this.caloriesFromFatResultsLabel.Name = "caloriesFromFatResultsLabel";
            this.caloriesFromFatResultsLabel.Size = new System.Drawing.Size(35, 13);
            this.caloriesFromFatResultsLabel.TabIndex = 0;
            this.caloriesFromFatResultsLabel.Text = "label1";
            // 
            // caloriesFromCarbsResultsLabel
            // 
            this.caloriesFromCarbsResultsLabel.AutoSize = true;
            this.caloriesFromCarbsResultsLabel.Location = new System.Drawing.Point(463, 181);
            this.caloriesFromCarbsResultsLabel.Name = "caloriesFromCarbsResultsLabel";
            this.caloriesFromCarbsResultsLabel.Size = new System.Drawing.Size(35, 13);
            this.caloriesFromCarbsResultsLabel.TabIndex = 0;
            this.caloriesFromCarbsResultsLabel.Text = "label1";
            // 
            // totalCaloriesLabel
            // 
            this.totalCaloriesLabel.AutoSize = true;
            this.totalCaloriesLabel.Location = new System.Drawing.Point(358, 234);
            this.totalCaloriesLabel.Name = "totalCaloriesLabel";
            this.totalCaloriesLabel.Size = new System.Drawing.Size(74, 13);
            this.totalCaloriesLabel.TabIndex = 0;
            this.totalCaloriesLabel.Text = "Total Calories:";
            // 
            // totaCaloriesResultsLabel
            // 
            this.totaCaloriesResultsLabel.AutoSize = true;
            this.totaCaloriesResultsLabel.Location = new System.Drawing.Point(463, 234);
            this.totaCaloriesResultsLabel.Name = "totaCaloriesResultsLabel";
            this.totaCaloriesResultsLabel.Size = new System.Drawing.Size(35, 13);
            this.totaCaloriesResultsLabel.TabIndex = 0;
            this.totaCaloriesResultsLabel.Text = "label1";
            // 
            // convertButton
            // 
            this.convertButton.Location = new System.Drawing.Point(243, 224);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(75, 23);
            this.convertButton.TabIndex = 2;
            this.convertButton.Text = "CONVERT";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // inputAdviseLabel
            // 
            this.inputAdviseLabel.AutoSize = true;
            this.inputAdviseLabel.ForeColor = System.Drawing.Color.Red;
            this.inputAdviseLabel.Location = new System.Drawing.Point(240, 78);
            this.inputAdviseLabel.Name = "inputAdviseLabel";
            this.inputAdviseLabel.Size = new System.Drawing.Size(220, 13);
            this.inputAdviseLabel.TabIndex = 0;
            this.inputAdviseLabel.Text = "Enter int or double only! example: 23 or 23.00";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 350);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.carbsGramsTextBox);
            this.Controls.Add(this.totaCaloriesResultsLabel);
            this.Controls.Add(this.totalCaloriesLabel);
            this.Controls.Add(this.caloriesFromCarbsResultsLabel);
            this.Controls.Add(this.caloriesFromCarbsLabel);
            this.Controls.Add(this.caloriesFromFatResultsLabel);
            this.Controls.Add(this.caloriesFromFatLabel);
            this.Controls.Add(this.carbsGrams);
            this.Controls.Add(this.fatGramsTextBox);
            this.Controls.Add(this.inputAdviseLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.fatGramsLabel);
            this.Name = "Form1";
            this.Text = "Exercise_8_CST_117 by Christopher Finster";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fatGramsLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox fatGramsTextBox;
        private System.Windows.Forms.Label carbsGrams;
        private System.Windows.Forms.TextBox carbsGramsTextBox;
        private System.Windows.Forms.Label caloriesFromFatLabel;
        private System.Windows.Forms.Label caloriesFromCarbsLabel;
        private System.Windows.Forms.Label caloriesFromFatResultsLabel;
        private System.Windows.Forms.Label caloriesFromCarbsResultsLabel;
        private System.Windows.Forms.Label totalCaloriesLabel;
        private System.Windows.Forms.Label totaCaloriesResultsLabel;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Label inputAdviseLabel;
    }
}

