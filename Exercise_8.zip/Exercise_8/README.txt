Christopher Finster
CST-117, Exercise 8
4 Apr 2021

This exercise is a demonstration of problem 4 of Chapter is in Starting out with Visual C Sharp (4th Edition).

I used a static class (Calories) with 2 overloaded methods:
  
     fatCalories(int) 
     fatCalories(double) 
     carbCalories(int) 
     carbCalories(double()

This is a Windows Form application for easy demonstration. 

This program will also display the total calories. 

You may enter the fat grams as an int or a double, and you may enter the carbs grams as an int or a double.

They can be mismatched ( one int and one double).  The program should recognize the data type and perform necessary conversions.

Program also retrievable at:

https://github.com/Finsternavy/CST-117/tree/main/Exercise_8/Exercise_8